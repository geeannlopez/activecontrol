//
//  Item.swift
//  PracticalQuiz3
//
//  Created by Katrin Villanes on 06/11/2017.
//  Copyright © 2017 FEU Tech. All rights reserved.
//

import UIKit

class Item: NSObject {

    var name: String
    var desc: String
    var real: String
    var imgSrc: String
    
    init(name: String, desc: String, real: String, imgSrc: String) {
        self.name = name
        self.desc = desc
        self.real = real
        self.imgSrc = imgSrc
    }
    
}
