//
//  ItemTableViewController.swift
//  PracticalQuiz3
//
//  Created by Katrin Villanes on 06/11/2017.
//  Copyright © 2017 FEU Tech. All rights reserved.
//

import UIKit

class ItemTableViewController: UITableViewController{
    @IBOutlet weak var imageView: UIImageView!

    @IBOutlet weak var tvDesc: UITextView!
    @IBOutlet weak var lblName: UILabel!
    
    private static var ITEMS: [Item] = [
        Item(name: "Yoo Seung-Ho", desc: "Yoo Seung-Ho was born on August, 1993. He is a popular South Korean actor & model. Yoo Seung-Ho first started in show business as a child actor and, like a lot of child actors, he started acting due to his mother. In 1999, Yoo Seung-Ho made his acting debut in a CF for n016. Prior to filming, the ad agency, responsible for the CF, was looking for a fresh face & not a professional model. Yoo Seung-Ho's mother then sent in a photo of her son and he was selected for the CF.", real: "Seo Jin-Woo", imgSrc: "k1"),
        
        Item(name: "Park Min-Young", desc: "Park Min Young is a popular South Korean actress. Born on March 4, 1986, she began her career in entertainment with a commercial for SK Telecom in 2005. She broke into acting a year later in the 2006 sitcom “Unstoppable High Kick!” She is best known for her leading roles in the television dramas “Sungkyunkwan Scandal” (2010), “City Hunter” (2011), “Dr. Jin” (2012), “A New Leaf” (2014), “Healer” (2014), “Remember” (2015) and “Queen for Seven Days” (2017).", real: "Lee In-A", imgSrc: "k2"),
        
        Item(name: "Park Sung-Woong", desc: "Park Sung-Woong and Shin Eun-Jung married on October 18, 2008 at Daemyung Vivaldi Park Hongcheon-gun Gangwon-do.The couple met while shooting the drama 'The Story of the First King's Four Gods. The couple has one son born on April 27, 2010.", real: "Park Dong-Ho", imgSrc: "k3"),
        
        Item(name: "Namgung Min", desc: "Namkoong first gained recognition with neo-noir film A Dirty Carnival (2006),[3] and drew widespread notice for his performance in Can You Hear My Heart? (2011).[4] After the series, Namkoong decided that he would only accept lead roles due to his new-found popularity and recognition, and turned down all offers of supporting roles. This led to an unwanted two years break for Nam.[5]", real: "Nam Gyoo-Man", imgSrc: "k4"),
        
        Item(name: "Jung Hye-Sung", desc: "Jung Hye-sung (born Jung Eun-joo on April 29, 1991) is a South Korean actress and model. She featured in television series Oh My Venus (2015) and Remember: War of the Son (2015), eventually gaining wider recognition for her role as Princess Myung-eun in Love in the Moonlight (2016). She plays her first leading role in Doubtful Victory.", real: "Nam Yeo-Kyung", imgSrc: "k5"),
        
        Item(name: "Jeon Kwang-Leol", desc: "Jun Kwang-ryul (Hangul: 전광렬; born February 11, 1960) is a South Korean actor. He is best known for his roles in the television series Hur Jun,Jumong and King of Baking, Kim Takgu.", real: "Seo Jae-Hyuk", imgSrc: "k6"),
        
        Item(name: "Kim Hyeong-Beom", desc: "A Day | Haroo (2017) - Kim Kyung-Wi, The File | Pail: 3022ilui Sayook (2015) - Min-Guk, Old Bicycle | Neurkeun Jajeongeo (2015) - Chang-Suk, Clown of a Salesman | Yakjangsoo (2015) - Jae-Yeol, Man On The Edge | Baksoogundal (2013) - smirky guy(Cha Tae-Joo's henchman), Neverending Story | Nebeoending seutoli (2012), My Girlfriend is an Agent | 7Keup Kongmuwon (2009) - Se-Kyun (Video Store Employee), Our School's E.T. | Woolhakgyo ET (2008) - English Teacher Cha Seung-Ryong, What, Happened Last Night? | Dongshini Jamdeun Saie (2008) - Jong-Tae",real:"Song Jae-Ik", imgSrc: "k7"),
        
        Item(name: "Han Jin-Hee", desc: "2. Han Jin-hee (born March 14, 1949) is a South Korean actor. He made his acting debut in 1969 and has remained active in television and film.[2] In 1990 he served as president of the TV Broadcasting Actors Association.", real: "Nam Il-Ho", imgSrc: "k8"),
        
        Item(name: "Lee Si-Un", desc: " Lee Si-eon (born Lee Bo-yeon on July 3, 1982) is a South Korean actor. He is best known for his comic supporting role in the popular campus drama Reply 1997.", real: "Ahn Soo-Bum", imgSrc: "k9"),
        
        Item(name: "Eom Hyo-Seop", desc: "Um Hyo-sup (born October 24, 1966) is a South Korean actor. Um mostly plays supporting roles in films and television dramas.", real: "Hong Moo-Suk", imgSrc: "k10"),
        
        ]
    

    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Uncomment the following line to preserve selection between presentations
        // self.clearsSelectionOnViewWillAppear = false

        // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
        // self.navigationItem.rightBarButtonItem = self.editButtonItem()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    // MARK: - Table view data source

    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return ItemTableViewController.ITEMS.count
    }

    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "itemID", for: indexPath)
        let row = indexPath.row
        cell.textLabel?.text = ItemTableViewController.ITEMS[row].name
        cell.detailTextLabel?.text = ItemTableViewController.ITEMS[row].real
        cell.imageView?.image = UIImage(named: ItemTableViewController.ITEMS[row].imgSrc)
        // Configure the cell...

        return cell
    }
    
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let row = indexPath.row
        lblName.text = ItemTableViewController.ITEMS[row].name
        tvDesc.text = ItemTableViewController.ITEMS[row].desc
        imageView.image = UIImage(named: ItemTableViewController.ITEMS[row].imgSrc)
        
        
    }
    /*
    // Override to support conditional editing of the table view.
    override func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the specified item to be editable.
        return true
    }
    */

    /*
    // Override to support editing the table view.
    override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            // Delete the row from the data source
            tableView.deleteRows(at: [indexPath], with: .fade)
        } else if editingStyle == .insert {
            // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
        }    
    }
    */

    /*
    // Override to support rearranging the table view.
    override func tableView(_ tableView: UITableView, moveRowAt fromIndexPath: IndexPath, to: IndexPath) {

    }
    */

    /*
    // Override to support conditional rearranging of the table view.
    override func tableView(_ tableView: UITableView, canMoveRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the item to be re-orderable.
        return true
    }
    */

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
