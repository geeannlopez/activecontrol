//
//  ViewController.swift
//  MP4
//
//  Created by Katrin Villanes on 02/11/2017.
//  Copyright © 2017 FEU Tech. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UIPickerViewDelegate, UIPickerViewDataSource {
    @IBOutlet weak var lblResult: UILabel!
    @IBOutlet weak var pickerView: UIPickerView!
    var n1:Float = 0.00, n2:Float = 0.00
    var oper = 0
    @IBOutlet weak var lblOperation: UILabel!
    var operators = ["+","-","*","/"]

    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 3
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        if component == 1 {
            return operators[row]
        }
        else{
            return String(row)
        }
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return component == 1 ? operators.count : 10
    }
    
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        
        if(component == 0 ){
            n1 = Float(row)
        }
        else if component == 1{
            oper = row
        }
        else if component == 2 {
            n2 = Float(row)
        }
        
        if oper == 0 {
            lblResult.text = String( n1 + n2 )
            lblOperation.text = "ADDITION"
        }
        else if oper == 1 {
            lblResult.text = String( n1 - n2 )
            lblOperation.text = "SUBTRACTION"
            
        }
        else if oper == 2 {
            lblResult.text = String( n1 * n2 )
            lblOperation.text = "MULTIPLICATION"
            
        }
        else if oper == 3 {
            lblResult.text = n2 == 0 ? "Undefined" : String( n1 / n2 )
            lblOperation.text = "DIVISION"
            
        }
        else{
            lblResult.text = "0.00"
            lblOperation.text = "None"
        }
        
        
        
        
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

