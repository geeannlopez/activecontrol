//
//  ViewController.swift
//  testing
//
//  Created by macstudent on 10/10/2017.
//  Copyright © 2017 FEUTECH. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    @IBOutlet weak var txtNum1: UITextField!
    @IBOutlet weak var txtNum2: UITextField!
    @IBOutlet weak var lblResult: UILabel!

    @IBAction func btnAdd(_ sender: Any) {
        if(txtNum1.text?.isEmpty)! || (txtNum2.text?.isEmpty)!{
            lblResult.text = "Blank field is not allowed"
        }
        else{
            lblResult.text = String( Float(txtNum1.text!)! + Float(txtNum2.text!)!)
        }
    }
    @IBAction func btnSub(_ sender: Any) {
        if(txtNum1.text?.isEmpty)! || (txtNum2.text?.isEmpty)!{
            lblResult.text = "Blank field is not allowed"
        }
        else{
            lblResult.text = String( Float(txtNum1.text!)! - Float(txtNum2.text!)!)
        }
    }
    @IBAction func btnMul(_ sender: Any) {
        if(txtNum1.text?.isEmpty)! || (txtNum2.text?.isEmpty)!{
            lblResult.text = "Blank field is not allowed"
        }
        else{
            lblResult.text = String( Float(txtNum1.text!)! * Float(txtNum2.text!)!)
        }
    }
    @IBAction func btnDiv(_ sender: Any) {
        if (Float(txtNum2.text!)! == 0){
            lblResult.text = "Zero is not allowed"
        }
        else if(txtNum1.text?.isEmpty)! || (txtNum2.text?.isEmpty)!{
            lblResult.text = "Blank field is not allowed"
        }
        else{
            lblResult.text = String( Float(txtNum1.text!)! / Float(txtNum2.text!)!)
        }
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

